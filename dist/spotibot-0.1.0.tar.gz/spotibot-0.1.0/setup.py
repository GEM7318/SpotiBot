# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['spotibot', 'spotibot.activity', 'spotibot.core']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'spotibot',
    'version': '0.1.0',
    'description': 'A small library to collect Spotify listening activity.',
    'long_description': None,
    'author': 'Grant Murray',
    'author_email': 'gmurray203@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
