

import spotipy.util as util
from spotibot.core import GetConfigs as cfg

client_id, client_secret, username_str = cfg.get_spotify_creds()


def refresh_headers(username: str) -> dict:
    """
    Utility function to refresh the access token given a username.
    """
    token = util.prompt_for_user_token(
        scope='user-top-read user-read-currently-playing '
              'user-read-playback-state user-library-read '
              'user-read-recently-played playlist-modify-public '
              'playlist-modify-private user-read-playback-position',
        username=username,
        client_id=client_id,
        client_secret=client_secret,
        redirect_uri=r'http://google.com/')
    headers = {f"Authorization": "Bearer {}".format(token)}
    return headers