
# Imports
import configparser
import os


def get_spotify_creds():
    """
    Function to read in Spotify API credentials from configuration file.
    :return: Tuple of client ID, client secret, and username
    """
    config = configparser.ConfigParser()
    config.read(r'C:\Users\gem7318\Documents\GitHub\SpotiBot\config.cfg')
    config.read(os.path.join(os.getcwd(), 'config.cfg'))

    client_id = config.get('SPOTIFY', 'CLIENT_ID')
    client_secret = config.get('SPOTIFY', 'CLIENT_SECRET')
    username_str = str(config.get('SPOTIFY', 'USERNAME'))

    return client_id, client_secret, username_str
