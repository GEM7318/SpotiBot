#!/usr/bin/env python
# coding: utf-8

import sys
import os

project_dir = r'/home/gem7318/Github/SpotiBot'
sys.path.append(project_dir)
os.chdir(project_dir)

import time
import requests

from spotibot.core import Hasher as hasher, FileManager as fmgr, Request as rb


class User:

    def __init__(self, user_id):
        self.user_id: str = \
            user_id

        self.activity_endpoint: str = \
            r'https://api.spotify.com/v1/me/player?additional_types=track,' \
            r'episode'

        self.user_playlist_dict = \
            fmgr.get_activity_playlist_for_user()

        self.user_activity_playlist_id = \
            self.user_playlist_dict.get(self.user_id)


class Context:

    def __init__(self, context: dict):
        self.href: str = \
            context.get('href', None)

        self.type: str = \
            context.get('type', None)

        self.uri: str = \
            context.get('uri', None)

        self.external_urls: str = \
            context.get('external_urls', None)


class Device:

    def __init__(self, device: dict):
        self.id = \
            device.get('id', None)

        self.is_active = \
            device.get('is_active', None)

        self.is_private_session = \
            device.get('is_private_session', None)

        self.is_restricted = \
            device.get('is_restricted', None)

        self.name = \
            device.get('name', None)

        self.type = \
            device.get('type', None)

        self.volume_percent = \
            device.get('volume_percent', None)


class Album:

    def __init__(self, album):
        self.album_type: str = \
            album.get('album_type', None)

        self.artists: list = \
            album.get('artists', None)

        self.available_markets: list = \
            album.get('available_markets', None)

        self.external_urls: str = \
            album.get('external_urls', None)
        # TODO: (Object Creation) Add ExternalUrl object and instantiate here

        self.href: str = \
            album.get('href', None)

        self.id: str = \
            album.get('id', None)

        self.images: list = \
            album.get('images', None)
        # TODO: (Object Creation) Create images object and instantiate here

        self.name: str = \
            album.get('name', None)

        self.release_date: str = \
            album.get('release_date', None)

        self.release_date_precision: str = \
            album.get('release_date_precision', None)

        self.restrictions: dict = \
            album.get('restrictions', None)

        self.tracks: list = \
            [Track(track) for track in album.get('tracks', None)]
        # TODO: Figure out how this is going to handle partial vs. full
        #  track objects.

        self.type: str = \
            album.get('type', None)

        self.uri: str = \
            album.get('uri', None)


class Artist:
    # TODO: Create full Artist Object even though the simplified object is
    #  all that's returned from User Currently Playing endpoint

    def __init__(self, artist):

        self.href: str = \
            artist.get('href', None)

        self.id: str = \
            artist.get('id', None)

        self.name: str = \
            artist.get('name', None)

        self.type: str = \
            artist.get('type', None)

        self.uri: str = \
            artist.get('uri', None)


class Track:

    def __init__(self, track):
        self.album: Album = \
            Album(track.get('album'))

        self.artists: list = \
            [Artist(artist) for artist in track.get('artists')]

        self.available_markets: list = \
            track.get('available_markets')

        self.disc_number: int = \
            track.get('disc_number')

        self.duration_ms: int = \
            track.get('duration_ms')

        self.explicit: bool = \
            track.get('explicit')

        self.external_ids: str = \
            track.get('external_ids')

        self.external_urls: str = \
            track.get('external_urls')

        self.href: str = \
            track.get('href')

        self.id: str = \
            track.get('id')

        self.is_local: bool = \
            track.get('is_local')

        self.name: str = \
            track.get('name')

        self.popularity: int = \
            track.get('popularity')

        self.preview_url: str = \
            track.get('preview_url')

        self.track_number: int = \
            track.get('track_number')

        self.type: str = \
            track.get('type')

        self.uri: str = \
            track.get('uri')

    def get_duration(self):
        return self.duration_ms


class Episode:

    def __init__(self, episode):
        self.audio_preview_url: str = \
            episode.get('audio_preview_url')

        self.description: str = \
            episode.get('description')

        self.duration_ms: int = \
            episode.get('duration_ms')

        self.explicit: bool = \
            episode.get('explicit')

        self.external_urls: str = \
            episode.get('external_urls')

        self.href: str = \
            episode.get('href')

        self.id: str = \
            episode.get('id')

        self.images: list = \
            episode.get('images')

        self.is_externally_hosted: bool = \
            episode.get('is_externally_hosted')

        self.is_playable: bool = \
            episode.get('is_playable')

        self.language: str = \
            episode.get('language')

        self.languages: list = \
            episode.get('languages')

        self.name: str = \
            episode.get('name')

        self.release_date: str = \
            episode.get('release_date')

        self.release_date_precision: str = \
            episode.get('release_date_precision')

        self.show = \
            episode.get('show')
        # TODO: (Object Creation) Create 'show' object and instantiate here

        self.type: str = \
            episode.get('type')

        self.uri: str = \
            episode.get('uri')

    def get_duration(self):
        return self.duration_ms


class Request(User):

    def __init__(self, user_id):
        super().__init__(user_id)
        self.user_id = user_id

        # --------------------------/Request Detail/---------------------------
        self.headers = rb.refresh_headers(user_id)

        self.unix_request_time_ms: int = \
            hasher.ns_to_ms(time.time_ns())

        self.response: requests.get = \
            requests.get(self.activity_endpoint, headers=self.headers)

        self.endpoint_id: str = \
            hasher.quick_hash(
                f"{self.activity_endpoint}{self.unix_request_time_ms}")
