#!/usr/bin/env python
# coding: utf-8

import sys
import os

project_dir = r'/home/gem7318/Github/SpotiBot'
sys.path.append(project_dir)
os.chdir(project_dir)

from spotibot.core import Objects as SpotiBot
from spotibot.core import FileManager as fmgr
from spotibot.core import GetConfigs as cfg


client_id, client_secret, username_str = cfg.get_spotify_creds()

activity_playlist_dict = fmgr.get_activity_playlist_for_user()
activity_playlist_id = activity_playlist_dict[username_str]


class Activity(SpotiBot.User):

    def __init__(self, user_id: str):

        super().__init__(user_id)

        # --------------------- Inherited Attributes --------------------------
        self.user_id: str = user_id

        # ------------------- Making / Verifying Request ----------------------
        self.request: SpotiBot.Request = SpotiBot.Request(self.user_id)

        if self.request.response.ok:
            self.result: dict = self.request.response.json()
        else:
            self.result: bool = False

        # ------------------------ Track / Show -------------------------------
        if self.result.get('currently_playing_type') == 'track':
            self.playback: SpotiBot.Track = SpotiBot.Track(self.result.get('item'))

        elif self.result.get('currently_playing_type') == 'episode':
            self.playback: SpotiBot.Episode = SpotiBot.Episode(self.result.get('item'))

        # -------------------------- Context ----------------------------------
        self.context: SpotiBot.Context = \
            SpotiBot.Context(self.result.get('context', None))

        # --------------------------- Device ----------------------------------
        self.device: SpotiBot.Device = \
            SpotiBot.Device(self.result.get('device'))

        # ----------- Freestanding Contextual Playback Information ------------
        self.playback.duration_ms = \
            self.playback.get_duration()

        self.playback.progress_ms = \
            self.result.get('progress_ms', None)

        self.playback.unix_request_time_ms = \
            self.request.unix_request_time_ms

        self.playback.unix_refresh_time_ms = \
            self.result.get('timestamp', None)

        self.playback.currently_playing_type = \
            self.result.get('currently_playing_type', None)

        self.playback.shuffle_state = \
            self.result.get('shuffle_state', None)

        self.playback.repeat_state = \
            self.result.get('repeat_state', None)

        self.playback.actions = \
            self.result.get('actions', None)

        self.playback.is_playing = \
            self.result.get('is_playing', None)

        # ----------------- Temporal Playback Information ---------------------
        self.playback.time_remaining_ms = \
            self.playback.duration_ms \
            - self.playback.progress_ms

        self.playback.unix_start_time_ms = \
            self.playback.unix_request_time_ms \
            - self.playback.progress_ms

        self.playback.unix_expected_end_time_ms = \
            self.playback.unix_request_time_ms \
            + self.playback.time_remaining_ms

    def __repr__(self):
        return f"Activity('{self.user_id}')"

    def __str__(self):
        return f"'Activity' Object for User: {self.user_id}"


class Delta:

    def __init__(self, latest: Activity, prior: Activity):
        self.latest = latest
        self.prior = prior

        # --------------------- Comparison (numeric) --------------------------
        self.progress_ms = \
            self.latest.playback.progress_ms \
            - self.prior.playback.progress_ms

        self.duration_ms = \
            self.latest.playback.duration_ms \
            - self.prior.playback.duration_ms

        self.time_remaining_ms = \
            self.latest.playback.time_remaining_ms \
            - self.prior.playback.time_remaining_ms

        self.unix_start_time_ms = \
            self.latest.playback.unix_start_time_ms \
            - self.prior.playback.unix_start_time_ms

        self.unix_request_time_ms = \
            self.latest.playback.unix_request_time_ms \
            - self.prior.playback.unix_request_time_ms

        self.unix_refresh_time_ms = \
            self.latest.playback.unix_refresh_time_ms \
            - self.prior.playback.unix_refresh_time_ms

        # --------------------- Comparison (boolean) --------------------------
        self.is_same_type = \
            type(self.latest.playback) is type(self.prior.playback)

        self.is_same_id = \
            self.latest.playback.id == self.prior.playback.id

        self.is_same_device = \
            self.latest.device.name == self.prior.device.name

        self.has_progressed = \
            self.progress_ms > 0

        self.progress_has_paused = \
            self.latest.playback.progress_ms \
            == self.prior.playback.progress_ms

        if not self.has_progressed \
                and not self.progress_has_paused \
                and self.latest.playback.progress_ms \
                > self.unix_request_time_ms:

            self.has_rewound = True

        else:

            self.has_rewound = False


class Combined:

    def __init__(self, latest: Activity, prior: Activity):
        self.latest = latest
        self.prior = prior
        self.delta = Delta(latest, prior)


# TODO: This should return a boolean value for new or same track as well as
#  what has occurred for user-facing logs

track1 = Activity(username_str)
track2 = Activity(username_str)

track1.playback.unix_refresh_time_ms  # 1589749931417
track2.playback.unix_refresh_time_ms  # 1589749931417

combined = Combined(track2, track1)

# ***********************
test = Current(username_str)

test.device.__dict__.items()
test.playback.__dict__.items()
test.playback.track.get('duration_ms')
test.playback.get_duration()
test.playback.track.get('duration_ms')
test
del test
help(test)

for k, v in test.__dict__.items():
    print(f"{k}: {v}")

    print(f"self.{k} = self.context.get('{k}', None)")

keys = [k for k in test.result.current_result.keys()]
for k in [k for k in test.result.current_result.keys()
          if k not in ['context', 'device']]:
    print(f"self.{k} = self.result.get('{k}', None)")


def generate_aggs(dict_to_traverse, base_attr):
    for att in dict_to_traverse.keys():
        print(f"self.{att} = \\ \n\t{base_attr}.get('{att}')\n")


to_generate = test.playback.__dict__.get('item')
to_generate
generate_aggs(to_generate, 'episode')

for k, v in test.result.device.__dict__.items():
    print(f"{k}:\n\t{v}")

for k, v in track1.__dict__.items():
    print(f"{k}:\n\t{v}")

for k, v in track1.result.__dict__.items():
    print(f"{k}:\n\t{v}")

for k, v in track1.result.__dict__.items():
    print(f"{k}")

    # ------------------- Time Listened Allocation ------------------------
    # if self.is_same_type:
    #     self.ms_current_start_to_prior_end = None
    # else:
    #     self.ms_current_start_to_prior_end = \
    #         self.current.playback.unix_start_time_ms \
    #         - self.prior.playback.unix_expected_end_time_ms

    # self.id = \
    #     self.current.id - self.prior.id

    # self.currently_playing_type = \
    #     self.current.currently_playing_type - self.prior.currently_playing_type

    # self.is_playing = \
    #     self.current.is_playing - self.prior.is_playing

    # self.unix_expected_end_time_ms = \
    #     self.current.playback.unix_expected_end_time_ms \
    #     - self.prior.playback.unix_expected_end_time_ms

isinstance(track1.playback, Track)

track1 = Current(username_str)
track2 = Current(username_str)

delta = Delta(track2, track1)

track1.playback.unix_request_time_ms
track2.playback.unix_request_time_ms
track2.playback.unix_request_time_ms - track1.playback.unix_request_time_ms

for k in test.playback.__dict__.keys():
    print(f"self.{k} = \n\tself.current.{k} - self.prior.{k}")
    print(k)

delta = Comparison(track2.result, track1.result)

for k, v in delta.__dict__.items():
    print(f"{k}:\n\t{v}")

test2 = test2.get()
for k, v in test2.__dict__.items():
    for k, v in track1.request.__dict__.items():
        # print(f"{k}:\n\t{v}")
        print(f"{k}")

test2.request.response.json()

help(test2)

print(test2)
print(test2.__repr__())

test2
